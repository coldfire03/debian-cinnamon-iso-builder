# teaiso
Muslim Linux iso build profile
