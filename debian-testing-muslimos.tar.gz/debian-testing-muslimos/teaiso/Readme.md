Teaiso
======

**The ISO generation tool for GNU/Linux**

## About Teaiso

Produces ISO of any kind of linux distribution as base. For more information check [doc](doc) directory. **Teaiso** is the iso generation tool of the **Tearch-linux** project at https://gitlab.com/tearch-linux, our goal is not being distro.

## Where to start

1. REQUIREMENTS AND INSTALL at [INSTALL.md](INSTALL.md) .
2. DOCUMENTATION AND USAGE: check [doc/Starting use case](doc/starting-use-case.md)

## LICENSE

Check [LICENSE](LICENSE) for more information
