#!/usr/bin/env bash
mkinitcpio -p linux
echo "Nothing to do!"
