#!/usr/bin/env bash
echo -e "live\nlive\n" | passwd
