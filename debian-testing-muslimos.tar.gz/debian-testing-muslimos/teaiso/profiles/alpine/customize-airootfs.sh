#!/usr/bin/env bash
echo -e "live\nlive\n" | passwd root
echo "Nothing to do!"
